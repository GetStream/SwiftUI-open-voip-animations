//
//  ChatsView.swift
//  StreamiOSChatSDKPrototyping
//
//  Created by amos.gyamfi@getstream.io on 14.10.2021.
//

import SwiftUI

struct ChatsView: View {
    
    var body: some View {
        VStack {
            Spacer()
            MessageListHeaderView()
            
            ScrollView { // Chat area
                VStack {
                    HStack { // Left Message
                        //InboundDoubleLineView()
                        InboundMessageView()
                        Spacer()
                    }
                    
                    HStack { // Right Message
                        Spacer()
                        OutboundSingleLineView()
                    }
                    
                    HStack { // Left Message
                        InboundSingleLineView()
                        Spacer()
                    }
                    
                    HStack { // Left Message
                        InboundDoubleLineView()
                        Spacer()
                    }
                    
                    HStack { // Right Message
                        Spacer()
                        ClappingHandsEmojiView()
                    }
                    
                    HStack { // Left Message
                        InboundTrippleLineView()
                        Spacer()
                    }
                    
                    HStack { // Right Message
                        Spacer()
                        OutboundTrippleLineView()
                    }
                    
                    HStack { // Right Message
                        Spacer()
                        OutboundDoubleLineView()
                    }
                    
                    HStack { // Right Message
                        Spacer()
                        OutboundSingleLineView()
                    }
                    
                    HStack { // Right Message
                        Spacer()
                        RevolvingHeartsView()
                            .padding(EdgeInsets(top: 40, leading: 0, bottom: 0, trailing: 40))
                    }
                }
                .padding()
            } // Chat area
            
            ComposeAreaView()
        } // All Views
    }
}

struct ChatsView_Previews: PreviewProvider {
    static var previews: some View {
        ChatsView()
            .preferredColorScheme(.dark)
    }
}
