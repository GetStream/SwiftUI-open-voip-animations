//
//  StreamiOSChatSDKPrototypingApp.swift
//  StreamiOSChatSDKPrototyping
//
//  Created by amos.gyamfi@getstream.io on 14.10.2021.
//

import SwiftUI

@main
struct StreamiOSChatSDKPrototypingApp: App {
    var body: some Scene {
        WindowGroup {
            SelectUserListView()
        }
    }
}
