//
//  SelectUserListView.swift
//  StreamiOSChatSDKPrototyping
//
//  Created by amos.gyamfi@getstream.io on 14.10.2021.
//

import SwiftUI

struct ChannelListEmptyView: View {
    let emptyChatColor = Color(#colorLiteral(red: 0.2997708321, green: 0.3221338987, blue: 0.3609524071, alpha: 1))
    var body: some View {
        VStack {
            HeaderView()
            Spacer()
            VStack {
                ZStack {
                    Image("emptyChatDark")
                    VStack {
                        HStack(spacing: 16) {
                            RoundedRectangle(cornerRadius: 2)
                                .frame(width: 8, height: 4)
                            RoundedRectangle(cornerRadius: 2)
                                .frame(width: 8, height: 4)
                        }
                        Circle()
                            .trim(from: 0, to: 1/2)
                            .stroke(style: StrokeStyle(lineWidth: 2, lineCap: .round, lineJoin: .round))
                            .frame(width: 16, height: 16)
                    }.foregroundColor(emptyChatColor)
                }
                
                
                Text("Let’s start chatting!")
                    .font(.body)
                Text("How about sending your first message to a friend?")
                    .font(.body)
                    .foregroundColor(.secondary)
                    .lineLimit(2)
                    .multilineTextAlignment(.center)
                    
            }
            Spacer()
            TabView {
                MentionsView()
                        .tabItem {
                            Label("Chats", image: "message_icon")
                        }
                        
                    MentionsView()
                        .tabItem {
                        Label("Mentions", systemImage: "at")
                    }
            }.frame(width: .infinity, height: 73)
        } // All Views
    }
}

struct ChannelListEmptyView_Previews: PreviewProvider {
    static var previews: some View {
        ChannelListEmptyView()
            .preferredColorScheme(.dark)
    }
}
