//
//  StreamLogoLaunchLineWave.swift
//  StreamiOSChatSDKPrototyping
//
//  Created by amos.gyamfi@getstream.io on 14.10.2021.
//

import SwiftUI

struct StreamLogoLaunchLineWave: View {
    let StreamBlue = Color(#colorLiteral(red: 0, green: 0.368627451, blue: 1, alpha: 1))
    @State private var swinging = false
    @State private var moving = false
    @State private var movingUp = false
    @State private var propelling = false
    let left = UIScreen.main.bounds.width
    let up = UIScreen.main.bounds.height
    
    var body: some View {
        if #available(iOS 15.0, *) {
            ZStack {
                StreamBlue
                    .opacity(0.25)
                    .ignoresSafeArea()
                VStack(spacing: -10) {
                Image("STREAMMARK")
                    .rotationEffect(.degrees(swinging ? -10 : 10), anchor: swinging ? .bottomLeading : .bottomTrailing)
                    .animation(.easeInOut(duration: 1).repeatForever(autoreverses: true), value: swinging)
                    .offset(x: propelling ? -left/2: left/2)
                
                Image("wave")
                    .offset(x: moving ? -left : left)
                    .animation(.linear(duration: 20).speed(3).repeatForever(autoreverses: false), value: swinging)
                
            }
            .offset(y: movingUp ? -up: up/2)
            .task {
                swinging.toggle()
                moving.toggle()
                
                withAnimation(.easeInOut(duration: 20).repeatForever(autoreverses: false)){
                    propelling.toggle()
                }
                
                withAnimation(.easeInOut(duration: 20).repeatForever(autoreverses: false)){
                    movingUp.toggle()
                }
        }
            }
    } else {
        // Fallback on earlier versions
    }
    }
}

struct StreamLogoLaunchLineWave_Previews: PreviewProvider {
    static var previews: some View {
        StreamLogoLaunchLineWave()
           
    }
}
