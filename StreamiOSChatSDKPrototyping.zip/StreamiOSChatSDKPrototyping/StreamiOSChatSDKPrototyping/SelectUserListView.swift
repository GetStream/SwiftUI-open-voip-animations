//
//  SelectUserListView.swift
//  StreamiOSChatSDKPrototyping
//
//  Created by amos.gyamfi@getstream.io on 14.10.2021.
//

import SwiftUI

struct SelectUserListView: View {
    
    var selectUsers: [SelectUserListStructure] = []
    let StreamBlue = Color(#colorLiteral(red: 0, green: 0.368627451, blue: 1, alpha: 1))
    
    var body: some View {
        VStack {
            Image("STREAMMARK")
            Text("Welcome to Stream Chat")
                .font(.title)
            Text("Select a user to try the iOS SDK")
                .padding()
            
            List(selectUsers) { item in
                HStack {
                    Image(item.avatar)
                    VStack(alignment: .leading){
                    Text("\(item.name)")
                        .fontWeight(.bold)
                    Text("\(item.user)")
                        .foregroundColor(.secondary)
                }
                       
                Spacer()
                       
                Image(systemName: item.selectUserArrow)
                    .foregroundColor(.blue)
            }
               }.listStyle(.inset)
        } // All Views
    }
}

struct SelectUserListView_Previews: PreviewProvider {
    static var previews: some View {
        SelectUserListView(selectUsers: SelectUserData)
            .preferredColorScheme(.dark)
    }
}
