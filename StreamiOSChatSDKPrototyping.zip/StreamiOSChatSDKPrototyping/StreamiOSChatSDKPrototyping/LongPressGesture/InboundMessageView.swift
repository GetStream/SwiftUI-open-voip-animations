//
//  ContentView.swift
//  Stream iOS Chat SDK Prototyping
//  Longpressing inbound message
//  Created by amos.gyamfi@getstream.io on 26.10.2021.
//

import SwiftUI

struct InboundMessageView: View {
    
    @State private var showReactionsBG = 0
    @State private var showLOLReaction = 0
    @State private var showLikeReaction = 0
    @State private var showLoveReaction = 0
    @State private var showUnlikeReaction = 0
    @State private var rotateThumb = -45
    @State private var showWhatReaction = 0
    let inboundBubbleColor = Color(#colorLiteral(red: 0.07058823529, green: 0.07843137255, blue: 0.0862745098, alpha: 1))
    let reactionsBGColor = Color(#colorLiteral(red: 0.07058823529, green: 0.07843137255, blue: 0.0862745098, alpha: 1))
    
    var body: some View {
        ZStack {
            /*Image("inboundbg")
                .blur(radius: 5)*/
            VStack(alignment: .leading) { // Container for Reactions, Inbound Message, Context Menu
                
                ZStack { // Reaction views
                    RoundedRectangle(cornerRadius: 28)
                        .frame(width: 216, height: 40)
                        .foregroundColor(reactionsBGColor)
                        .scaleEffect(Double(showReactionsBG), anchor: .topTrailing)
                        .animation(.interpolatingSpring(stiffness: 170, damping: 15).delay(0.05), value: showReactionsBG)
                        
                    HStack(spacing: 20) {
                        Image("like")
                            .scaleEffect(Double(showLoveReaction))
                        Image("thumbs_up")
                            .scaleEffect(Double(showLikeReaction))
                            .rotationEffect(.degrees(Double(rotateThumb)), anchor: .bottomLeading)
                        Image("thumbs_down")
                            .scaleEffect(Double(showUnlikeReaction))
                            .rotationEffect(.degrees(Double(rotateThumb)), anchor: .topTrailing)
                        Image("lol")
                            .scaleEffect(Double(showLOLReaction))
                        Image("wut_reaction")
                            .scaleEffect(Double(showWhatReaction))
                    }
                   
                } // All reaction views
                    HStack(alignment: .bottom) {
                        Image("luke")
                            .resizable()
                            .frame(width: 36, height: 36)
                        
                        VStack(alignment: .leading) {
                            ZStack(alignment: .bottomLeading) {
                                RoundedRectangle(cornerRadius: 21)
                                    .frame(width: 272, height: 56)
                                    .overlay(
                                        Text("Ladies and gentlemen, we have liftoff")
                                            .foregroundColor(.white)
                                    )
                                Rectangle()
                                    .frame(width: 20, height: 21)
                            }
                            // Inbound Message Bubble
                            .foregroundColor(inboundBubbleColor)
                                
                            Text("Is that Stream Chat?. Fabulous  18.37")
                                .font(.footnote)
                            .foregroundColor(.secondary)
                        }
                    }.onLongPressGesture{
                        showReactionsBG = 1
                        
                        withAnimation(.interpolatingSpring(stiffness: 170, damping: 8).delay(0.1)) {
                            showLOLReaction = 1
                        }
                        
                        withAnimation(.interpolatingSpring(stiffness: 170, damping: 8).delay(0.2)) {
                            showLikeReaction = 1
                            rotateThumb = 0
                        }
                        
                        withAnimation(.interpolatingSpring(stiffness: 170, damping: 8).delay(0.3)) {
                            showLoveReaction = 1
                        }
                        
                        withAnimation(.interpolatingSpring(stiffness: 170, damping: 8).delay(0.4)) {
                            showUnlikeReaction = 1
                            rotateThumb = 0
                        }
                        
                        withAnimation(.interpolatingSpring(stiffness: 170, damping: 8).delay(0.5)) {
                            showWhatReaction = 1
                        }
                }// Show context menu here when longpressed
                
            } // Container for Reactions, Inbound Message, Context Menu
    }
}

struct InboundMessageView_Previews: PreviewProvider {
    static var previews: some View {
        InboundMessageView()
            .preferredColorScheme(.dark)
    }
}
}
