//
//  ContentView.swift
//  Stream iOS Chat SDK Prototyping
//
//  Created by amos.gyamfi@getstream.io on 14.10.2021.
//

import SwiftUI

struct ReactionsView: View {
    
    let reactionsBGColor = Color(#colorLiteral(red: 0.07058823529, green: 0.07843137255, blue: 0.0862745098, alpha: 1))
    @State private var showReactionsBG = 0
    @State private var showLOLReaction = 0
    @State private var showLikeReaction = 0
    @State private var showLoveReaction = 0
    @State private var showUnlikeReaction = 0
    @State private var rotateThumb = -45
    @State private var showWhatReaction = 0
    
    //@State private var showReactionsBackground = false

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 28)
                .frame(width: 216, height: 40)
                .foregroundColor(reactionsBGColor)
                //.scaleEffect(Double(showReactionsBG), anchor: .topTrailing)
                //.animation(.interpolatingSpring(stiffness: 170, damping: 15).delay(0.05), value: showReactionsBG)
                
            HStack(spacing: 20) {
                Image("like")
                    //.scaleEffect(Double(showLoveReaction))
                Image("thumbs_up")
                    //.scaleEffect(Double(showLikeReaction))
                    //.rotationEffect(.degrees(Double(rotateThumb)), anchor: .bottomLeading)
                Image("thumbs_down")
                    //.scaleEffect(Double(showUnlikeReaction))
                    //.rotationEffect(.degrees(Double(rotateThumb)), anchor: .topTrailing)
                Image("lol")
                    //.scaleEffect(Double(showLOLReaction))
                Image("wut_reaction")
                    //.scaleEffect(Double(showWhatReaction))
            }
           
        } // All reaction views
    }
}

struct ReactionsView_Previews: PreviewProvider {
    static var previews: some View {
        ReactionsView()
            .preferredColorScheme(.dark)
    }
}
