//
//  PhotoInteractionApp.swift
//  PhotoInteraction
//
//  Created by amos.gyamfi@getstream.io on 31.1.2022.
//

import SwiftUI

@main
struct PhotoInteractionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
